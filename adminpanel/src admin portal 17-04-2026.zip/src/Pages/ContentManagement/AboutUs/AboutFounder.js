// import React from 'react'

// const LevelOfSrtudy = () => {
//   return (
//     <div>LevelOfSrtudy</div>
//   )
// }

// export default LevelOfSrtudy

import React, { useEffect, useState } from "react";
import CustomTable from "../../../Components/Table/CustomTable";
// import BannerinputGetModal from '../../Modal/BannerModal/BannerinputGetModaldal';
import { Grid } from "@mui/material";
// import BannerinputGetModal from '../../../CommonModal/BannerModal/BannerinputGetModal';
import { useDispatch, useSelector } from "react-redux";
import actions from "../../../ReduxStore/actions";
import { toast, ToastContainer } from "react-toastify";
import "../../../Components/ModalCss/BannerinputGetModal.css";
// import LevelOfStudyModal from "./Modal/LevelOfStudyModal";
import { updateProgrammeLevelAction } from "../../../ReduxStore/Slices/ProgramLevel/updateProgrammeLevel";
import BannerModal from "./Modal/BannerModal";
import AboutFounderModal from "./Modal/AboutFounderModal";
// import LandingPage from '../../Preview/LandingPage';
// import PreviewComponent from "../../PreviewComponent/PreviewComponent";
// import StakeNowMainPage from "../../ContentManagementStakeNowPreview/Banner/StakeNowMainPage";
// import BannerinputGetModal from "../Modal/Banner/BannerinputGetModal";

const AboutFounder = () => {
  // const permissions = JSON.parse(sessionStorage.getItem("permissions"));
  // // const permissions = JSON.parse(sessionStorage.getItem("permissions"));
  // const role = sessionStorage.getItem("role")
  // csonole

  // const tableData = role === "superAdmin"
  //   ? [{ title: 'The Best Gold', secondtext: 'Staking Company', subtext: 'Lorem Ipsum is simply dummy text of the...', documents: "banner.jpg" }]
  //   : [];

  const tableHeadData = ["S.No","Sub Title","Description"];

  const dispatch = useDispatch();

  const [responseTableData, setResponseTableData] = useState([]);
  // const permissions = JSON.parse(sessionStorage.getItem("permissions"));

  const [rowTableData, setRowTableData] = useState([]);
  console.log(rowTableData, "rowTableTAdatatattattat");

  const { getAllAboutUsSectionsBySectionName } = useSelector(
    (state) => state?.getAllAboutUsSectionsBySectionName
  );
  const { updateAboutUsSection } = useSelector(
    (state) => state?.updateAboutUsSection
  );
  const { addAboutUsSection } = useSelector(
    (state) => state?.addAboutUsSection
  );
  console.log(
    getAllAboutUsSectionsBySectionName,
    "getAllAboutUsSectionsBySectionName"
  );
  useEffect(() => {
    const fetchData = async () => {
      const data1 = {
        data: {
          section_name: "aboutFounder section",
        },
        method: "post",
        apiName: `getAllAboutUsSectionsBySectionName`,
      };

      const responseData = await dispatch(
        actions.GETALLABOUTUSSECTIONSBYSECTIONNAME(data1)
      );
      console.log(responseData, "responseData");
      setResponseTableData(responseData?.payload);
    };

    fetchData();
  }, [responseTableData,addAboutUsSection, updateAboutUsSection]);

  useEffect(() => {
    const tempArr = [];

    responseTableData?.data?.map((data) => {
      tempArr.push({
        id: data?.section_id,
        subtext: data?.additional_data?.subtext?.map((t) => limitText(t)),
        description: data?.additional_data?.description?.map((t) =>
          limitText(t)
        ),
      });
    });

    setRowTableData(tempArr);
  }, [responseTableData]);

  const limitText = (text) =>
    text?.length > 50 ? text.substring(0, 50) + "..." : text;

  console.log(rowTableData, "rowTableDatattattata");

  const handleTableEdit = (id) => {
    console.log(id, "TableIddddd");

    const data1 = {
      data: {},
      method: "get",
      apiName: `getAboutUsSectionById/${id}`,
    };
    dispatch(actions.GETABOUTUSSECTIONBYID(data1));
  };

  return (
    <Grid container spacing={2}>
      <Grid size={{ xs: 12 }}>
        <CustomTable
          // tableEdit="tableEdit"
          // tableDelete="tableDelete"

          tableData={rowTableData}
          title="About Founder"
          tableHeadData={tableHeadData}
          //   modalName={BannerinputGetModal}
          //   editModalName={BannerinputGetModal}

          // const permissions = JSON.parse(sessionStorage.getItem("permissions"));
          // tableView={true}
          //   modalVeiwName={PreviewComponent}
          //   ModalPreviewComponent1={StakeNowMainPage}
          // handleTableDataDelete={handleTableDataDelete}

          // tableDelete={true}
          tableEdit={true}
          dataCreate={!getAllAboutUsSectionsBySectionName?.data?.length > 0}
          //   getAllAboutUsSectionsBySectionName?.data?.additional_data
          //     ? true
          //     : false
          // }
          //   apiBasedName="stakeNowBannerInputModal"
          //   tableData={rowTableData}
          //   title="Banner"
          //   tableHeadData={tableHeadData}
          modalName={AboutFounderModal}
          handleTableEdit={handleTableEdit}
          editModalName={AboutFounderModal}
          //   handleTableDataDelete={handleTableDataDelete}
        />
      </Grid>
    </Grid>
  );
};

export default AboutFounder;
