// export const adminUrl = "http://122.165.52.124:4000/api/v1/";
// export const adminUrl = "http://localhost:5000/api/v1/";

// Development url
// export const adminUrl = "http://192.168.1.186:5000/api/v1/";

// production url
export const adminUrl = "https://ethiraj.api.finecons.com/api/v1/";
// export const adminUrl = "http://192.168.1.157:5000/api/v1/";

export const loginUrl = "";
